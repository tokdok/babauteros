#!/bin/sh
cd /tmp/tmpfoldername/
echo "Start"
while (true) 
do
 ./4.sh;
 sleep pausefour; 
  ./2.sh;
 sleep pausetwo; 
   ./5.sh;
 sleep pausefive; 
   ./3.sh;
 sleep pausethree; 
   ./6.sh;
 sleep pausesix; 
  ./1.sh;
 sleep pauseone; 
done;





